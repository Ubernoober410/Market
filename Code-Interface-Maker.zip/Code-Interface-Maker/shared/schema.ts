import { pgTable, text, serial, integer, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const games = pgTable("games", {
  id: serial("id").primaryKey(),
  money: integer("money").notNull().default(350000),
  health: integer("health").notNull().default(100),
  threat: integer("threat").notNull().default(30),
  hour: integer("hour").notNull().default(0),
  location: text("location").notNull().default("Apartment"),
  provocation: integer("provocation").notNull().default(0),
  tauntCount: integer("taunt_count").notNull().default(0),
  guardActive: boolean("guard_active").notNull().default(false),
  inventory: jsonb("inventory").$type<string[]>().notNull().default([]),
  loopholeCounter: integer("loophole_counter").notNull().default(0),
  hitmanAttempted: boolean("hitman_attempted").notNull().default(false),
  hitmanKilled: boolean("hitman_killed").notNull().default(false),
  hitmanNotLocations: jsonb("hitman_not_locations").$type<number[]>().notNull().default([]),
  isGameOver: boolean("is_game_over").notNull().default(false),
  gameResult: text("game_result"), // 'victory', 'defeat', 'survived'
  logs: jsonb("logs").$type<string[]>().notNull().default([]),
});

export const insertGameSchema = createInsertSchema(games);
export type Game = typeof games.$inferSelect;
export type InsertGame = z.infer<typeof insertGameSchema>;

export const actionSchema = z.object({
  type: z.enum(['move', 'lay_low', 'scavenge', 'buy_defense', 'taunt', 'hire_hitman', 'gather_intel']),
  params: z.object({
    defenseItem: z.enum(['safehouse', 'disguise', 'bodyguard', 'medibag']).optional(),
    hitmanLocationGuess: z.number().min(1).max(10).optional(),
  }).optional()
});

export type ActionRequest = z.infer<typeof actionSchema>;
