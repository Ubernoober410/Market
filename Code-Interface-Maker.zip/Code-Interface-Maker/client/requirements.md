## Packages
framer-motion | Animations for UI elements and transitions
clsx | Utility for conditional class names (usually part of standard stack but good to ensure)
tailwind-merge | Utility for merging tailwind classes

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["'Oxanium'", "sans-serif"],
  mono: ["'JetBrains Mono'", "monospace"],
  body: ["'Inter'", "sans-serif"],
}
