import { useState } from "react";
import { useGame, useGameAction } from "@/hooks/use-game";
import { useToast } from "@/hooks/use-toast";
import { StatusIndicator } from "@/components/StatusIndicator";
import { TerminalLog } from "@/components/TerminalLog";
import { ActionButton } from "@/components/ActionButton";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { 
  ShieldAlert, 
  MapPin, 
  Clock, 
  DollarSign, 
  Heart, 
  Footprints, 
  EyeOff, 
  Search, 
  ShoppingBag, 
  Skull, 
  Crosshair, 
  AlertTriangle,
  BriefcaseMedical,
  UserCheck,
  Home,
  Ghost
} from "lucide-react";
import { motion } from "framer-motion";

interface GameDashboardProps {
  gameId: number;
}

export default function GameDashboard({ gameId }: GameDashboardProps) {
  const { data: game, isLoading: isGameLoading } = useGame(gameId);
  const { mutate: performAction, isPending } = useGameAction();
  const { toast } = useToast();
  
  // State for hire hitman modal
  const [hitmanGuess, setHitmanGuess] = useState<string>("");
  const [isHitmanModalOpen, setIsHitmanModalOpen] = useState(false);
  const [isDefenseModalOpen, setIsDefenseModalOpen] = useState(false);

  if (isGameLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background text-primary font-mono">
        <div className="flex flex-col items-center gap-4">
          <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
          <p className="animate-pulse">INITIALIZING SYSTEM...</p>
        </div>
      </div>
    );
  }

  if (!game) return <div>Game not found</div>;

  // Handle game over / result screens
  if (game.isGameOver) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-black relative overflow-hidden p-4">
        <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1550684848-fac1c5b4e853?q=80&w=2070&auto=format&fit=crop')] bg-cover bg-center opacity-10 blur-sm pointer-events-none" />
        {/* Abstract tech background */}
        
        <div className="max-w-2xl w-full bg-card border border-border p-8 rounded-lg shadow-2xl z-10 text-center relative overflow-hidden">
          <div className="scanline absolute inset-0 opacity-20 pointer-events-none"></div>
          
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.5 }}
          >
            <h1 className={cn(
              "text-6xl font-display font-black mb-4 tracking-tighter text-glow",
              game.gameResult === 'victory' || game.gameResult === 'survived' ? "text-green-500" : "text-red-500"
            )}>
              {game.gameResult === 'victory' ? "TARGET ELIMINATED" : 
               game.gameResult === 'survived' ? "SURVIVED" : "KIA"}
            </h1>
            
            <p className="text-xl text-muted-foreground font-mono mb-8">
              {game.gameResult === 'victory' 
                ? "You successfully located and eliminated the hitman. The contract is closed." 
                : game.gameResult === 'survived'
                ? "You survived for 24 hours. The hitman lost your trail."
                : "The hitman found you. Better luck in the next life."}
            </p>
            
            <div className="grid grid-cols-2 gap-4 mb-8 text-left max-w-md mx-auto">
              <div className="bg-black/30 p-3 rounded border border-border">
                <p className="text-xs text-muted-foreground uppercase">Money Remaining</p>
                <p className="text-xl font-mono text-green-400">${game.money.toLocaleString()}</p>
              </div>
              <div className="bg-black/30 p-3 rounded border border-border">
                <p className="text-xs text-muted-foreground uppercase">Hours Survived</p>
                <p className="text-xl font-mono text-primary">{game.hour}/24</p>
              </div>
            </div>
            
            <Button 
              onClick={() => window.location.reload()} 
              size="lg" 
              className="bg-primary hover:bg-primary/90 text-primary-foreground font-display tracking-widest text-lg px-12"
            >
              REBOOT SYSTEM
            </Button>
          </motion.div>
        </div>
      </div>
    );
  }

  const handleAction = (type: string, params: any = {}) => {
    performAction(
      { gameId, action: { type: type as any, params } },
      {
        onError: (err) => {
          toast({
            title: "Action Failed",
            description: err.message,
            variant: "destructive",
          });
        },
        onSuccess: () => {
          if (type === 'hire_hitman') setIsHitmanModalOpen(false);
          if (type === 'buy_defense') setIsDefenseModalOpen(false);
        }
      }
    );
  };

  return (
    <div className="min-h-screen bg-background text-foreground font-sans p-2 md:p-6 lg:p-8 flex flex-col gap-6 max-w-7xl mx-auto">
      
      {/* Top HUD */}
      <header className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatusIndicator 
          label="Hour" 
          value={game.hour} 
          max={24} 
          icon={<Clock className="w-4 h-4 text-cyan-400" />} 
        />
        <StatusIndicator 
          label="Location" 
          value={game.location} 
          icon={<MapPin className="w-4 h-4 text-cyan-400" />} 
        />
        <StatusIndicator 
          label="Threat Level" 
          value={game.threat} 
          max={100} 
          color={game.threat > 70 ? "destructive" : game.threat > 40 ? "warning" : "primary"}
          icon={<ShieldAlert className="w-4 h-4 text-red-400" />} 
        />
        <StatusIndicator 
          label="Health" 
          value={game.health} 
          max={100} 
          color={game.health < 30 ? "destructive" : "primary"}
          icon={<Heart className="w-4 h-4 text-pink-500" />} 
        />
      </header>
      
      {/* Money Bar */}
      <div className="w-full bg-card border border-border p-4 flex justify-between items-center rounded-sm shadow-lg">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-green-500/10 rounded-full border border-green-500/30">
            <DollarSign className="w-6 h-6 text-green-400" />
          </div>
          <div>
            <p className="text-xs text-muted-foreground uppercase font-mono">Available Funds</p>
            <p className="text-2xl font-display font-bold text-green-400 text-glow">${game.money.toLocaleString()}</p>
          </div>
        </div>
        
        {/* Inventory Tags */}
        <div className="flex gap-2">
          {game.inventory.map((item, idx) => (
            <div key={idx} className="px-3 py-1 bg-secondary border border-secondary-foreground/20 rounded-full text-xs font-mono text-secondary-foreground flex items-center gap-1">
              {item === 'safehouse' && <Home className="w-3 h-3" />}
              {item === 'disguise' && <Ghost className="w-3 h-3" />}
              {item === 'bodyguard' && <UserCheck className="w-3 h-3" />}
              {item === 'medibag' && <BriefcaseMedical className="w-3 h-3" />}
              {item.toUpperCase()}
            </div>
          ))}
          {game.inventory.length === 0 && (
            <span className="text-xs text-muted-foreground italic font-mono px-2 py-1">NO INVENTORY</span>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 flex-1 min-h-[500px]">
        
        {/* Main Action Grid */}
        <div className="lg:col-span-2 grid grid-cols-1 md:grid-cols-2 gap-4 auto-rows-min">
          
          <ActionButton
            label="Move Location"
            cost={20000}
            subtext="Change your position to evade detection. Reduces threat."
            icon={<Footprints className="w-5 h-5" />}
            onClick={() => handleAction('move')}
            isLoading={isPending}
            disabled={game.isGameOver}
          />

          <ActionButton
            label="Lay Low"
            cost={0}
            subtext="Stay quiet and hidden. Reduces threat significantly but time passes."
            icon={<EyeOff className="w-5 h-5" />}
            onClick={() => handleAction('lay_low')}
            isLoading={isPending}
            disabled={game.isGameOver}
          />
          
          <ActionButton
            label="Scavenge"
            subtext="Look for resources. Small chance of finding money or items. Increases threat."
            icon={<Search className="w-5 h-5" />}
            onClick={() => handleAction('scavenge')}
            isLoading={isPending}
            disabled={game.isGameOver}
            className="md:col-span-2"
          />

          <Dialog open={isDefenseModalOpen} onOpenChange={setIsDefenseModalOpen}>
            <DialogTrigger asChild>
              <ActionButton
                label="Buy Defense"
                subtext="Purchase equipment to improve your survival odds."
                icon={<ShoppingBag className="w-5 h-5" />}
                variant="secondary"
                disabled={game.isGameOver}
              />
            </DialogTrigger>
            <DialogContent className="sm:max-w-md bg-card border-border font-mono">
              <DialogHeader>
                <DialogTitle className="font-display text-xl text-primary uppercase">Black Market</DialogTitle>
                <DialogDescription>Purchase assets to aid your survival.</DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <Button 
                  variant="outline" 
                  className="justify-between h-auto py-3 border-border hover:border-primary/50 group"
                  onClick={() => handleAction('buy_defense', { defenseItem: 'safehouse' })}
                  disabled={game.money < 50000 || game.inventory.includes('safehouse')}
                >
                  <div className="flex flex-col items-start">
                    <span className="font-bold flex items-center gap-2"><Home className="w-4 h-4"/> Safehouse</span>
                    <span className="text-xs text-muted-foreground font-light">Huge threat reduction</span>
                  </div>
                  <span className="text-red-400 group-hover:text-red-300 font-mono font-bold">$50,000</span>
                </Button>
                
                <Button 
                  variant="outline" 
                  className="justify-between h-auto py-3 border-border hover:border-primary/50 group"
                  onClick={() => handleAction('buy_defense', { defenseItem: 'disguise' })}
                  disabled={game.money < 25000 || game.inventory.includes('disguise')}
                >
                  <div className="flex flex-col items-start">
                    <span className="font-bold flex items-center gap-2"><Ghost className="w-4 h-4"/> Disguise</span>
                    <span className="text-xs text-muted-foreground font-light">Evade detection easier</span>
                  </div>
                  <span className="text-red-400 group-hover:text-red-300 font-mono font-bold">$25,000</span>
                </Button>
                
                <Button 
                  variant="outline" 
                  className="justify-between h-auto py-3 border-border hover:border-primary/50 group"
                  onClick={() => handleAction('buy_defense', { defenseItem: 'bodyguard' })}
                  disabled={game.money < 40000 || game.inventory.includes('bodyguard')}
                >
                  <div className="flex flex-col items-start">
                    <span className="font-bold flex items-center gap-2"><UserCheck className="w-4 h-4"/> Bodyguard</span>
                    <span className="text-xs text-muted-foreground font-light">Protection from attacks</span>
                  </div>
                  <span className="text-red-400 group-hover:text-red-300 font-mono font-bold">$40,000</span>
                </Button>
                
                <Button 
                  variant="outline" 
                  className="justify-between h-auto py-3 border-border hover:border-primary/50 group"
                  onClick={() => handleAction('buy_defense', { defenseItem: 'medibag' })}
                  disabled={game.money < 30000 || game.inventory.includes('medibag')}
                >
                  <div className="flex flex-col items-start">
                    <span className="font-bold flex items-center gap-2"><BriefcaseMedical className="w-4 h-4"/> Medibag</span>
                    <span className="text-xs text-muted-foreground font-light">Restores health</span>
                  </div>
                  <span className="text-red-400 group-hover:text-red-300 font-mono font-bold">$30,000</span>
                </Button>
              </div>
            </DialogContent>
          </Dialog>

          <ActionButton
            label="Gather Intel"
            cost={20000}
            subtext="Investigate the hitman's location. Helps narrow down where they are not."
            icon={<Crosshair className="w-5 h-5" />}
            onClick={() => handleAction('gather_intel')}
            isLoading={isPending}
            disabled={game.isGameOver}
            variant="secondary"
          />

          <ActionButton
            label="Taunt Hitman"
            subtext="Lure them out. Increases threat significantly but may force an error."
            icon={<AlertTriangle className="w-5 h-5" />}
            onClick={() => handleAction('taunt')}
            isLoading={isPending}
            disabled={game.isGameOver}
            variant="accent"
          />

          <Dialog open={isHitmanModalOpen} onOpenChange={setIsHitmanModalOpen}>
            <DialogTrigger asChild>
              <ActionButton
                label="Eliminate Hitman"
                cost={250000}
                subtext="Attempt to locate and terminate the contract yourself. Win condition."
                icon={<Skull className="w-5 h-5" />}
                variant="destructive"
                disabled={game.isGameOver || game.money < 250000}
              />
            </DialogTrigger>
            <DialogContent className="sm:max-w-md bg-destructive/10 border-destructive/50 text-destructive-foreground font-mono backdrop-blur-xl">
              <DialogHeader>
                <DialogTitle className="font-display text-xl text-destructive uppercase">Confirm Kill Order</DialogTitle>
                <DialogDescription className="text-destructive/80">
                  This action costs $250,000. You must correctly guess the hitman's location (1-10).
                  Wrong guess wastes money and time.
                </DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="flex flex-col gap-2">
                  <Label htmlFor="location" className="text-destructive font-bold">Target Location Sector (1-10)</Label>
                  <Input
                    id="location"
                    type="number"
                    min="1"
                    max="10"
                    placeholder="Enter sector..."
                    className="bg-black/50 border-destructive/50 text-white placeholder:text-destructive/30 focus:border-destructive"
                    value={hitmanGuess}
                    onChange={(e) => setHitmanGuess(e.target.value)}
                  />
                  
                  {game.hitmanNotLocations.length > 0 && (
                    <div className="text-xs text-destructive/70 mt-2 p-2 border border-destructive/30 rounded bg-black/40">
                      <strong>Intel - Cleared Sectors:</strong> {game.hitmanNotLocations.join(', ')}
                    </div>
                  )}
                </div>
              </div>
              <DialogFooter>
                <Button 
                  variant="destructive" 
                  onClick={() => handleAction('hire_hitman', { hitmanLocationGuess: parseInt(hitmanGuess) })}
                  disabled={!hitmanGuess || isPending}
                  className="w-full font-bold tracking-widest"
                >
                  {isPending ? "PROCESSING..." : "EXECUTE"}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>

        </div>

        {/* Event Log */}
        <div className="lg:h-full min-h-[400px]">
          <TerminalLog logs={game.logs} />
        </div>
      </div>
    </div>
  );
}
