import { useCreateGame } from "@/hooks/use-game";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { ArrowRight, Crosshair, Shield, Cpu } from "lucide-react";
import { motion } from "framer-motion";

export default function Home() {
  const [, setLocation] = useLocation();
  const createGameMutation = useCreateGame();

  const handleStartGame = () => {
    createGameMutation.mutate(undefined, {
      onSuccess: (data) => {
        setLocation(`/game/${data.id}`);
      },
    });
  };

  return (
    <div className="min-h-screen bg-background flex flex-col relative overflow-hidden font-sans">
      {/* Background with abstract cyber elements */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-blue-900/20 via-background to-background pointer-events-none" />
      <div className="absolute inset-0 scanline opacity-10 pointer-events-none" />
      
      {/* Navbar placeholder */}
      <div className="w-full p-6 border-b border-white/5 flex justify-between items-center z-10 backdrop-blur-sm">
        <div className="flex items-center gap-2">
          <Cpu className="w-6 h-6 text-primary" />
          <span className="font-display font-bold text-xl tracking-wider text-primary">SURVIVAL.EXE</span>
        </div>
        <div className="text-xs font-mono text-muted-foreground">SYSTEM_STATUS: ONLINE</div>
      </div>

      <main className="flex-1 flex flex-col justify-center items-center px-4 relative z-10 max-w-5xl mx-auto w-full">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          
          {/* Left Column: Hero Text */}
          <motion.div 
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="flex flex-col gap-6"
          >
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 border border-primary/20 text-primary text-xs font-mono w-fit">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-primary"></span>
              </span>
              NEW CONTRACT AVAILABLE
            </div>

            <h1 className="text-5xl md:text-7xl font-display font-black leading-tight tracking-tighter text-transparent bg-clip-text bg-gradient-to-r from-white via-white to-white/50">
              SURVIVE <br/>
              <span className="text-primary text-glow">THE NIGHT</span>
            </h1>
            
            <p className="text-lg text-muted-foreground leading-relaxed max-w-md">
              You are being hunted. A professional hitman is on your trail. 
              You have $350,000, 24 hours, and your wits. 
              Can you survive or will you turn the tables?
            </p>

            <div className="flex flex-col sm:flex-row gap-4 mt-4">
              <Button 
                size="lg" 
                onClick={handleStartGame}
                disabled={createGameMutation.isPending}
                className="bg-primary hover:bg-primary/90 text-primary-foreground font-display tracking-widest text-lg h-14 px-8 shadow-[0_0_20px_rgba(6,182,212,0.3)] hover:shadow-[0_0_30px_rgba(6,182,212,0.5)] transition-all"
              >
                {createGameMutation.isPending ? "INITIALIZING..." : "INITIATE PROTOCOL"}
                {!createGameMutation.isPending && <ArrowRight className="ml-2 w-5 h-5" />}
              </Button>
              
              <Button 
                size="lg" 
                variant="outline"
                className="font-mono text-muted-foreground border-white/10 hover:bg-white/5 hover:text-white h-14"
              >
                VIEW INTEL
              </Button>
            </div>
          </motion.div>

          {/* Right Column: Visual Elements */}
          <motion.div 
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="relative hidden lg:block"
          >
            <div className="absolute inset-0 bg-gradient-to-tr from-primary/20 to-accent/20 blur-3xl rounded-full opacity-30" />
            
            <div className="relative bg-card/50 border border-border/50 backdrop-blur-xl p-6 rounded-lg shadow-2xl">
              <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-primary to-transparent opacity-50" />
              
              <div className="grid gap-6">
                <div className="flex items-center gap-4 p-4 bg-black/40 rounded border border-white/5">
                  <div className="p-3 bg-red-500/20 rounded text-red-400">
                    <Crosshair className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="font-display text-white font-bold">Threat Assessment</h3>
                    <p className="text-sm text-muted-foreground">Manage your threat level to avoid detection.</p>
                  </div>
                </div>

                <div className="flex items-center gap-4 p-4 bg-black/40 rounded border border-white/5">
                  <div className="p-3 bg-cyan-500/20 rounded text-cyan-400">
                    <Shield className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="font-display text-white font-bold">Defensive Assets</h3>
                    <p className="text-sm text-muted-foreground">Purchase safehouses, disguises, and protection.</p>
                  </div>
                </div>
                
                {/* Simulated Terminal Output */}
                <div className="font-mono text-xs p-4 bg-black rounded border border-white/10 text-green-500/80">
                  <p>&gt; Scanning local networks...</p>
                  <p>&gt; Target identified.</p>
                  <p>&gt; Threat level: CRITICAL</p>
                  <p>&gt; <span className="animate-pulse">Awaiting user input_</span></p>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </main>

      <footer className="w-full p-6 border-t border-white/5 text-center text-xs text-muted-foreground font-mono z-10">
        SECURE TERMINAL CONNECTION V1.0.4 // UNAUTHORIZED ACCESS PROHIBITED
      </footer>
    </div>
  );
}
