import { useEffect, useRef } from "react";
import { ScrollArea } from "@/components/ui/scroll-area";
import { motion, AnimatePresence } from "framer-motion";
import { Terminal } from "lucide-react";

interface TerminalLogProps {
  logs: string[];
}

export function TerminalLog({ logs }: TerminalLogProps) {
  const bottomRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to bottom when logs change
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [logs]);

  return (
    <div className="flex flex-col h-full bg-black/80 border border-border overflow-hidden rounded-sm relative font-mono text-sm shadow-inner shadow-black/50">
      <div className="flex items-center gap-2 p-3 border-b border-border bg-card/30 backdrop-blur-md">
        <Terminal className="w-4 h-4 text-primary animate-pulse" />
        <span className="text-xs uppercase tracking-widest text-primary/80 font-bold">System Log</span>
        <div className="ml-auto flex gap-1">
          <div className="w-2 h-2 rounded-full bg-red-500/20"></div>
          <div className="w-2 h-2 rounded-full bg-yellow-500/20"></div>
          <div className="w-2 h-2 rounded-full bg-green-500/50"></div>
        </div>
      </div>
      
      <ScrollArea className="flex-1 p-4 relative">
         <div className="scanline absolute inset-0 pointer-events-none z-10 opacity-10"></div>
         <div className="flex flex-col gap-2">
            {logs.length === 0 && (
              <div className="text-muted-foreground italic opacity-50 text-xs">
                &gt; System initialized. Awaiting events...
              </div>
            )}
            <AnimatePresence initial={false}>
              {logs.map((log, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="flex gap-2 items-start"
                >
                  <span className="text-primary/50 select-none">{'>'}</span>
                  <span className={log.includes("DANGER") || log.includes("HITMAN") ? "text-red-400" : "text-green-50/90"}>
                    {log}
                  </span>
                </motion.div>
              ))}
            </AnimatePresence>
            <div ref={bottomRef} />
         </div>
      </ScrollArea>
    </div>
  );
}
