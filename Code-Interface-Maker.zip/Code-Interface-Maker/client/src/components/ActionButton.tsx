import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { Loader2 } from "lucide-react";

interface ActionButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  label: string;
  cost?: number;
  subtext?: string;
  variant?: "default" | "destructive" | "outline" | "ghost" | "secondary" | "accent";
  isLoading?: boolean;
  icon?: React.ReactNode;
}

export function ActionButton({ 
  label, 
  cost, 
  subtext, 
  variant = "default", 
  isLoading, 
  icon,
  className,
  disabled,
  ...props 
}: ActionButtonProps) {
  
  const getVariantStyles = () => {
    switch (variant) {
      case "accent": return "bg-accent/10 border-accent/50 text-accent hover:bg-accent/20 hover:border-accent hover:text-white";
      case "destructive": return "bg-destructive/10 border-destructive/50 text-destructive hover:bg-destructive/20 hover:border-destructive hover:text-white";
      case "secondary": return "bg-secondary/50 border-secondary-foreground/20 text-secondary-foreground hover:bg-secondary hover:border-secondary-foreground/50";
      default: return "bg-primary/5 border-primary/30 text-primary hover:bg-primary/10 hover:border-primary hover:text-white hover:shadow-[0_0_15px_rgba(6,182,212,0.3)]";
    }
  };

  return (
    <Button
      variant="outline"
      className={cn(
        "h-auto py-4 px-4 flex flex-col items-start justify-between gap-2 border w-full transition-all duration-300 relative overflow-hidden group rounded-sm",
        getVariantStyles(),
        className
      )}
      disabled={disabled || isLoading}
      {...props}
    >
      {/* Background decoration */}
      <div className="absolute top-0 right-0 w-8 h-8 bg-current opacity-[0.03] -mr-4 -mt-4 rotate-45 group-hover:opacity-[0.07] transition-opacity" />
      
      <div className="flex w-full justify-between items-center mb-1">
        <span className="font-display font-bold text-lg tracking-wide uppercase flex items-center gap-2">
          {icon}
          {label}
        </span>
        {isLoading && <Loader2 className="w-4 h-4 animate-spin" />}
      </div>
      
      <div className="flex w-full justify-between items-end text-xs font-mono opacity-80 group-hover:opacity-100">
        <span className="max-w-[70%] text-left leading-tight">{subtext}</span>
        {cost !== undefined && (
          <span className={cn("font-bold", cost > 0 ? "text-red-400" : "text-green-400")}>
             {cost > 0 ? `-$${cost.toLocaleString()}` : 'FREE'}
          </span>
        )}
      </div>
    </Button>
  );
}
