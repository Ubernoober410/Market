import { cn } from "@/lib/utils";
import { motion } from "framer-motion";

interface StatusIndicatorProps {
  label: string;
  value: number | string;
  max?: number;
  color?: "primary" | "destructive" | "accent" | "warning";
  icon?: React.ReactNode;
  animateChange?: boolean;
}

export function StatusIndicator({
  label,
  value,
  max,
  color = "primary",
  icon,
  animateChange = true
}: StatusIndicatorProps) {
  
  const getProgressColor = () => {
    switch (color) {
      case "destructive": return "bg-red-500 shadow-[0_0_10px_rgba(239,68,68,0.5)]";
      case "accent": return "bg-pink-500 shadow-[0_0_10px_rgba(236,72,153,0.5)]";
      case "warning": return "bg-yellow-500 shadow-[0_0_10px_rgba(234,179,8,0.5)]";
      default: return "bg-cyan-500 shadow-[0_0_10px_rgba(6,182,212,0.5)]";
    }
  };

  const percent = typeof value === 'number' && max ? Math.min(100, Math.max(0, (value / max) * 100)) : 0;

  return (
    <div className="flex flex-col gap-1 w-full p-3 bg-card/50 border border-border/50 backdrop-blur-sm rounded-sm">
      <div className="flex justify-between items-center text-xs font-mono uppercase tracking-wider text-muted-foreground mb-1">
        <span className="flex items-center gap-2">
          {icon}
          {label}
        </span>
        <motion.span 
          key={String(value)}
          initial={animateChange ? { scale: 1.2, color: "#fff" } : undefined}
          animate={animateChange ? { scale: 1, color: "var(--foreground)" } : undefined}
          className="font-bold text-foreground"
        >
          {typeof value === 'number' ? value.toLocaleString() : value}
          {max && <span className="text-muted-foreground/50"> / {max}</span>}
        </motion.span>
      </div>
      
      {max !== undefined && (
        <div className="h-2 w-full bg-background/50 overflow-hidden relative border border-white/5 rounded-sm">
          <motion.div 
            className={cn("h-full transition-all duration-500", getProgressColor())}
            initial={{ width: 0 }}
            animate={{ width: `${percent}%` }}
          />
        </div>
      )}
    </div>
  );
}
