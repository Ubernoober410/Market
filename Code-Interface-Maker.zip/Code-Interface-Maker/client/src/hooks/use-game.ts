import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl, type ActionRequest } from "@shared/routes";
import { games } from "@shared/schema";
import { z } from "zod";

// Validating the response against the schema defined in shared/routes
const gameSchema = api.games.get.responses[200];
type Game = z.infer<typeof gameSchema>;

export function useGame(id?: number) {
  return useQuery({
    queryKey: [api.games.get.path, id],
    queryFn: async () => {
      if (!id) return null;
      const url = buildUrl(api.games.get.path, { id });
      const res = await fetch(url);
      if (res.status === 404) return null;
      if (!res.ok) throw new Error("Failed to fetch game state");
      return gameSchema.parse(await res.json());
    },
    enabled: !!id,
    refetchInterval: 5000, // Poll occasionally to sync state if needed
  });
}

export function useCreateGame() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async () => {
      const res = await fetch(api.games.create.path, {
        method: api.games.create.method,
      });
      if (!res.ok) throw new Error("Failed to create new game");
      return api.games.create.responses[201].parse(await res.json());
    },
    onSuccess: (data) => {
      // Invalidate relevant queries or handle redirection in UI
      queryClient.setQueryData([api.games.get.path, data.id], data);
    },
  });
}

export function useGameAction() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({ gameId, action }: { gameId: number; action: ActionRequest }) => {
      const url = buildUrl(api.games.action.path, { id: gameId });
      
      // Client-side validation before sending
      const validatedAction = api.games.action.input.parse(action);

      const res = await fetch(url, {
        method: api.games.action.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validatedAction),
      });

      if (!res.ok) {
        if (res.status === 400) {
          const error = api.games.action.responses[400].parse(await res.json());
          throw new Error(error.message);
        }
        if (res.status === 404) {
             throw new Error("Game not found");
        }
        throw new Error("Action failed");
      }
      
      return api.games.action.responses[200].parse(await res.json());
    },
    onSuccess: (data) => {
      // Optimistically update the game state
      queryClient.setQueryData([api.games.get.path, data.id], data);
      
      // Also invalidate to be safe
      queryClient.invalidateQueries({ queryKey: [api.games.get.path, data.id] });
    },
  });
}
