import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api, errorSchemas } from "@shared/routes";
import { z } from "zod";
import { actionSchema } from "@shared/schema";

// Game Constants
const TOTAL_HOURS = 24;

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  app.post(api.games.create.path, async (req, res) => {
    try {
      const game = await storage.createGame({});
      res.status(201).json(game);
    } catch (err) {
      res.status(500).json({ message: "Failed to create game" });
    }
  });

  app.get(api.games.get.path, async (req, res) => {
    try {
      const game = await storage.getGame(Number(req.params.id));
      if (!game) {
        return res.status(404).json({ message: "Game not found" });
      }
      res.json(game);
    } catch (err) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post(api.games.action.path, async (req, res) => {
    try {
      const gameId = Number(req.params.id);
      let game = await storage.getGame(gameId);
      
      if (!game) {
        return res.status(404).json({ message: "Game not found" });
      }

      if (game.isGameOver) {
        return res.status(400).json({ message: "Game is over" });
      }

      const action = actionSchema.parse(req.body);
      const updates: any = { ...game }; // Clone state for modification
      const logEntry: string[] = [...(game.logs || [])];

      // Helper to add log
      const addLog = (msg: string) => {
        logEntry.push(`Hour ${updates.hour + 1}: ${msg}`);
      };

      // --- 1. Process Player Action ---
      let hourPassed = true; // Most actions take an hour
      updates.hour += 1;

      switch (action.type) {
        case 'move':
          if (updates.money >= 20000) {
            updates.money -= 20000;
            const locations = ["Hotel", "Cafe", "Safehouse", "Bus Station"];
            updates.location = locations[Math.floor(Math.random() * locations.length)];
            
            const heal = Math.floor(Math.random() * (20 - 12 + 1)) + 12; // 12-20
            updates.health = Math.min(100, updates.health + heal);
            
            const threatReduction = Math.floor(Math.random() * (12 - 5 + 1)) + 5; // 5-12
            updates.threat = Math.max(0, updates.threat - threatReduction);
            
            addLog(`Moved to ${updates.location}. Health +${heal}, Threat -${threatReduction}.`);

            if (Math.random() < 0.3) {
              const found = Math.floor(Math.random() * (15000 - 5000 + 1)) + 5000;
              updates.money += found;
              addLog(`You found $${found.toLocaleString()} while moving!`);
            }
          } else {
            updates.loopholeCounter += 1;
            addLog("Insufficient funds to move. Hour still counts.");
          }
          break;

        case 'lay_low':
          const layLowHeal = Math.floor(Math.random() * (15 - 8 + 1)) + 8; // 8-15
          updates.health = Math.min(100, updates.health + layLowHeal);
          updates.threat = Math.max(0, updates.threat - 5);
          addLog(`You lay low. Health +${layLowHeal}, Threat -5.`);
          break;

        case 'scavenge':
          const threatIncrease = Math.floor(Math.random() * (15 - 5 + 1)) + 5; // 5-15
          updates.threat = Math.min(100, updates.threat + threatIncrease);
          addLog(`You scavenge... but attract attention! Threat +${threatIncrease}.`);
          
          if (Math.random() < 0.01) {
             const newInventory = [...(updates.inventory || [])];
             newInventory.push("prank_note");
             updates.inventory = newInventory;
             addLog('You find a small note: "There’s nothing overpowered, it’s a prank!"');
          }
          break;

        case 'buy_defense':
          if (!action.params?.defenseItem) {
             updates.hour -= 1; // Cancel didn't take time in original, but here we enforce action structure. Let's assume menu nav doesn't take time if canceled? 
             // Actually, the original code: "buy_defense" function -> input choice. 
             // If valid purchase -> money deducted, item added.
             // If insufficient funds -> loophole++, hour still counts.
             // If cancel -> "Purchase canceled." -> loop continues, BUT in original code `buy_defense()` is called inside the loop, and `valid_action = True` is set ONLY if a choice was made. Wait.
             // Original: 
             //  if choice == "4": buy_defense(); valid_action = True
             // Inside buy_defense: asks for input. If cancel, prints "Purchase canceled".
             // It seems even canceling counts as an action in the original loop structure because `valid_action = True` is set after `buy_defense()` returns. 
             // So canceling wastes an hour? "Purchase canceled." -> returns to main loop. `valid_action = True` executes. Loop restarts. `player["hour"] += 1`.
             // YES. Canceling wastes an hour in the original code logic provided! 
             // "Purchase canceled." -> returns. valid_action=True. Loop continues. Hour increments.
             addLog("Purchase canceled.");
          } else {
            const item = action.params.defenseItem;
            let cost = 0;
            if (item === 'safehouse') cost = 50000;
            if (item === 'disguise') cost = 25000;
            if (item === 'bodyguard') cost = 40000;
            if (item === 'medibag') cost = 30000;

            if (updates.money >= cost) {
              updates.money -= cost;
              if (item === 'bodyguard') updates.guardActive = true;
              
              if (item === 'medibag') {
                 const heal = 30;
                 updates.health = Math.min(100, updates.health + heal);
                 addLog(`Used medibag. Health +${heal}.`);
              } else {
                 const newInventory = [...(updates.inventory || [])];
                 if (!newInventory.includes(item)) {
                   newInventory.push(item);
                   updates.inventory = newInventory;
                 }
                 addLog(`Bought ${item}.`);
              }
            } else {
              updates.loopholeCounter += 1;
              addLog(`Insufficient funds for ${item}. Hour still counts.`);
            }
          }
          break;

        case 'taunt':
          updates.tauntCount += 1;
          updates.provocation += 2;
          updates.threat += 20;
          if (updates.tauntCount === 1) {
            addLog("⚠️ You taunt the hitman once. Warning!");
          } else {
            addLog("❌ You taunt the hitman again. Instant death!");
            updates.health = 0;
          }
          break;

        case 'hire_hitman':
          if (updates.hitmanAttempted) {
            addLog("You've already attempted to put a hit on the hitman. Attempt wasted.");
          } else if (updates.money < 250000) {
            updates.loopholeCounter += 1;
            addLog("Not enough money to hire a hitman ($250k needed). Hour wasted.");
          } else {
            updates.money -= 250000;
            updates.hitmanAttempted = true;
            
            // Logic: generate hitman location excluding known NOT locations
            const allLocs = Array.from({length: 10}, (_, i) => i + 1);
            const knownNot = new Set((updates.hitmanNotLocations || []) as number[]);
            const possible = allLocs.filter(l => !knownNot.has(l));
            
            // Random choice from possible
            const hitmanLoc = possible[Math.floor(Math.random() * possible.length)];
            const guess = action.params?.hitmanLocationGuess;

            if (guess === hitmanLoc) {
              updates.hitmanKilled = true;
              updates.health = 101; // Special flag for early win
              updates.hour = TOTAL_HOURS; // End game
              addLog("Success! You found and eliminated the hitman. You win early!");
            } else {
              const newNotLocs = [...(updates.hitmanNotLocations || [])];
              if (guess && !newNotLocs.includes(guess)) {
                 newNotLocs.push(guess);
                 updates.hitmanNotLocations = newNotLocs;
              }
              addLog("The hitman was not there. Your attempt is used up.");
            }
          }
          break;

        case 'gather_intel':
          if (updates.money < 20000) {
            updates.loopholeCounter += 1;
            addLog("Not enough money to gather intel. Hour wasted.");
          } else {
            updates.money -= 20000;
            const allLocs = Array.from({length: 10}, (_, i) => i + 1);
            const knownNot = new Set((updates.hitmanNotLocations || []) as number[]);
            const unknown = allLocs.filter(l => !knownNot.has(l));

            if (unknown.length <= 2) {
              addLog("Intel network exhausted. No new information.");
            } else {
              // Reveal 1 or 2 locations
              const numReveals = Math.floor(Math.random() * 2) + 1; // 1 or 2
              // Shuffle unknown
              const shuffled = unknown.sort(() => 0.5 - Math.random());
              const revealed = shuffled.slice(0, numReveals);
              
              const newNotLocs = [...(updates.hitmanNotLocations || []), ...revealed];
              updates.hitmanNotLocations = newNotLocs; // JSONB handles array
              
              addLog(`📡 Intel gathered. Hitman NOT in: ${revealed.join(', ')}.`);
            }
          }
          break;
      }

      // --- 2. Hitman Action (End of Turn) ---
      // Only if game not already over (health > 0)
      if (updates.health > 0 && updates.hour <= TOTAL_HOURS) {
         if (updates.provocation >= 3) {
            const attackChance = 0.2 + 0.1 * (updates.provocation - 3);
            if (Math.random() < attackChance) {
               addLog("⚠️ The hitman confronts you!");
               if (updates.guardActive) {
                 addLog("🛡️ Your bodyguard handles the situation safely.");
               } else {
                 let dmg = 0;
                 if (updates.provocation < 6) {
                   dmg = Math.floor(Math.random() * (15 - 5 + 1)) + 5; // 5-15
                 } else {
                   dmg = Math.floor(Math.random() * (25 - 15 + 1)) + 15; // 15-25
                 }
                 updates.health -= dmg;
                 updates.threat = Math.max(0, updates.threat - 10);
                 addLog(`You escape but are hurt (-${dmg} health).`);
               }
            }
         }
      }

      // --- 3. Check End Game Conditions ---
      if (updates.health <= 0) {
        updates.health = 0;
        updates.isGameOver = true;
        updates.gameResult = "defeat";
        addLog("The hitman got you. You are dead.");
      } else if (updates.hour >= TOTAL_HOURS || updates.hitmanKilled) {
        updates.isGameOver = true;
        updates.gameResult = "victory";
        if (updates.hitmanKilled) {
           addLog(`VICTORY! You survived and eliminated the hitman! Money: $${updates.money.toLocaleString()}`);
        } else {
           addLog(`VICTORY! You survived! Money: $${updates.money.toLocaleString()}`);
        }
      }

      updates.logs = logEntry;
      
      const updatedGame = await storage.updateGame(gameId, updates);
      res.json(updatedGame);

    } catch (err) {
      if (err instanceof z.ZodError) {
         res.status(400).json({ message: "Invalid action parameters" });
      } else {
         console.error(err);
         res.status(500).json({ message: "Internal server error" });
      }
    }
  });

  return httpServer;
}
